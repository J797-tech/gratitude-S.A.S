package com.tienda.tiendacelularesgui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

// Clase Carrito para manejar los productos en el carrito de compras
class Carrito {
    private final List<TiendaCelularesGUI.Producto> productos;

    public Carrito() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(TiendaCelularesGUI.Producto producto) {
        productos.add(producto);
    }

    public void eliminarProducto(TiendaCelularesGUI.Producto producto) {
        productos.remove(producto);
    }

    public void vaciarCarrito() {
        productos.clear();
    }

    public List<TiendaCelularesGUI.Producto> getProductos() {
        return productos;
    }

    public double calcularTotal() {
        double total = 0;
        for (TiendaCelularesGUI.Producto producto : productos) {
            total += producto.getPrecio();
        } 
        return total;
    }
}


public class TiendaCelularesGUI extends JFrame {
    private final List<Producto> productos;
    private JPanel panel;
    private JPanel panelProductos; // Panel para los productos
    private Producto productoSeleccionado; // Variable para almacenar el producto seleccionado
    private JComboBox<String> comboFiltroPrecio;
    private Carrito carrito; 
    

    

    public TiendaCelularesGUI() {
        productos = new ArrayList<>();
        carrito = new Carrito(); 
        cargarProductos();
        initUI();
    }

    private void verCarrito() {
        List<TiendaCelularesGUI.Producto> productosEnCarrito = carrito.getProductos();
        
        if (productosEnCarrito.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El carrito está vacío.", "Carrito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            StringBuilder detallesCarrito = new StringBuilder("Productos en el carrito:\n");
            for (int i = 0; i < productosEnCarrito.size(); i++) {
                detallesCarrito.append(i + 1).append(". ")
                                .append(productosEnCarrito.get(i).getNombre())
                                .append(" - Precio: $")
                                .append(productosEnCarrito.get(i).getPrecio())
                                .append(" COP\n");
            }
            detallesCarrito.append("Total: $").append(carrito.calcularTotal()).append(" COP");
            
            // Mostrar el carrito y pedir al usuario que elija un producto para eliminar
            String input = JOptionPane.showInputDialog(this, detallesCarrito.toString() + "\n\nIngrese el número del producto a eliminar (o cancelar para salir):");
            
            if (input != null && !input.isEmpty()) {
                try {
                    int index = Integer.parseInt(input) - 1;
                    if (index >= 0 && index < productosEnCarrito.size()) {
                        carrito.eliminarProducto(productosEnCarrito.get(index));
                        JOptionPane.showMessageDialog(this, "Producto eliminado del carrito.", "Producto Eliminado", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, "Número de producto inválido.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Entrada no válida.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void agregarAlCarrito() {
        if (productoSeleccionado != null) {
            carrito.agregarProducto(productoSeleccionado);
            JOptionPane.showMessageDialog(this, productoSeleccionado.getNombre() + " ha sido agregado al carrito.", "Producto Agregado", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un producto antes de agregarlo al carrito.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void aceptarCompra() {
        double total = carrito.calcularTotal();
        if (total > 0) {
            JOptionPane.showMessageDialog(this, "Compra aceptada. Total a pagar: $" + total + " COP", "Compra Aceptada", JOptionPane.INFORMATION_MESSAGE);
            carrito.vaciarCarrito(); 
        } else {
            JOptionPane.showMessageDialog(this, "El carrito está vacío. No se puede realizar la compra.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    class Producto {
        private final String nombre; 
        private final double precio;
        private final ImageIcon imagen;
        private final String especificaciones; //  campo para especificaciones

        public Producto(String nombre, double precio, String urlImagen, String especificaciones) {
            this.nombre = nombre;
            this.precio = precio;
            this.imagen = cargarImagen(urlImagen);
            this.especificaciones = especificaciones; // Inicializar especificaciones
        }

        @SuppressWarnings("deprecation")
        private ImageIcon cargarImagen(String urlImagen) {
            try {
                BufferedImage img = ImageIO.read(new URL(urlImagen));
                int originalWidth = img.getWidth();
                int originalHeight = img.getHeight();
                int nuevoAncho = 300; // Cambia este valor según tus necesidades
                int nuevaAltura = (int) ((double) originalHeight * nuevoAncho / originalWidth);
                Image scaledImg = img.getScaledInstance(nuevoAncho, nuevaAltura, Image.SCALE_SMOOTH);
                return new ImageIcon(scaledImg);
            } catch (IOException e) {
                System.out.println("Error al cargar la imagen desde la URL: " + urlImagen);
                return null; // Manejo de error
            }
        }
        
        public String getNombre() {
            return nombre;
        }

        public double getPrecio() {
            return precio;
        }

        public ImageIcon getImagen() {
            return imagen;
        }

        public String getEspecificaciones() {
            return especificaciones; // Método para obtener especificaciones
        }
    }

    private void cargarProductos() {
        // Cargar productos usando URLs y especificaciones
        productos.add(new Producto("iPhone 14 Pro Max", 1099, "https://i.pinimg.com/736x/ec/7c/9e/ec7c9e7e73194ef43f36815b4640bc1f.jpg",
            "Pantalla: 6.7\" Super Retina XDR\nProcesador: A16 Bionic\nRAM: 6 GB\nAlmacenamiento: 128/256/512 GB, 1 TB\nCámara trasera: Triple (48 MP + 12 MP + 12 MP)\nCámara frontal: 12 MP\nBatería: Hasta 29 horas de duración\nSistema operativo: iOS 16"));
        
        productos.add(new Producto("Nubia Z60 Ultra 5G", 8999, "https://i.pinimg.com/736x/23/db/a6/23dba674f10e58b71507bcb37de9d771.jpg",
            "Pantalla: 6.8\" AMOLED\nProcesador: Snapdragon 8 Gen 1\nRAM: 8/12 GB\nAlmacenamiento: 256/512 GB\nCámara trasera: Triple (64 MP + 50 MP + 8 MP)\nCámara frontal: 16 MP\nBatería: 5000 mAh\nSistema operativo: Android 12"));

        productos.add(new Producto("Red Magic 9 Pro+", 9999, "https://i.pinimg.com/736x/2f/4e/d9/2f4ed91652b8ed5a4ae7791d2d1c4460.jpg",
            "Pantalla: 6.8\" AMOLED\nProcesador: Snapdragon 8 Gen 1\nRAM: 12/16 GB\nAlmacenamiento: 256/512 GB\nCámara trasera: Triple (64 MP + 8 MP + 2 MP)\nCámara frontal: 16 MP\nBatería: 4500 mAh\nSistema operativo: Android 12"));

            productos.add(new Producto("Samsung Galaxy S24", 11999, "https://i.pinimg.com/736x/94/a5/2f/94a52f54bb8123ce1852549b010bd950.jpg",
            "Pantalla: 6.1\" Dynamic AMOLED 2X\nProcesador: Exynos 2200 o Snapdragon 8 Gen 2\nRAM: 8 GB\nAlmacenamiento: 128/256 GB\nCámara trasera: Triple (50 MP + 12 MP + 10 MP)\nCámara frontal: 12 MP\nBatería: 4000 mAh\nSistema operativo: Android 13"));

        productos.add(new Producto("Xiaomi 14 Ultra 16/512GB", 12999, "https://i.pinimg.com/736x/af/af/95/afaf95248c0b0379fd09f777164c1d0f.jpg",
            "Pantalla: 6.73\" AMOLED\nProcesador: Snapdragon 8 Gen 2\nRAM: 16 GB\nAlmacenamiento: 512 GB\nCámara trasera: Cuádruple (50 MP + 50 MP + 50 MP + 50 MP)\nCámara frontal: 32 MP\nBatería: 5000 mAh\nSistema operativo: Android 13"));

        productos.add(new Producto("Hono X7A", 2999, "https://i.pinimg.com/736x/c1/98/8a/c1988a78d4e4a77225e1338f70bd6371.jpg",
            "Pantalla: 6.67\" IPS LCD\nProcesador: MediaTek Helio G37\nRAM: 4/6 GB\nAlmacenamiento: 64/128 GB\nCámara trasera: Cuádruple (50 MP + 2 MP + 2 MP + 2 MP)\nCámara frontal: 8 MP\nBatería: 5000 mAh\nSistema operativo: Android 12"));

        productos.add(new Producto("Smartphone Realme 12 Pro + Plus 5G", 5999, "https://i.pinimg.com/736x/f1/7c/aa/f17caa934898c9ef9264b272797cc3f2.jpg",
            "Pantalla: 6.7\" AMOLED\nProcesador: MediaTek Dimensity 8100\nRAM: 12 GB\nAlmacenamiento: 512 GB\nCámara trasera: Triple (108 MP + 8 MP + 2 MP)\nCámara frontal: 16 MP\nBatería: 5000 mAh\nSistema operativo: Android 12"));

        productos.add(new Producto("Xiaomi Poco M6 Pro", 3999, "https://i.pinimg.com/736x/5f/57/08/5f57089c9520efe339a8f7699d558c4a.jpg",
            "Pantalla: 6.58\" IPS LCD\nProcesador: Snapdragon 4 Gen 2\nRAM: 4/6 GB\nAlmacenamiento: 64/128 GB\nCámara trasera: Doble (50 MP + 2 MP)\nCámara frontal: 8 MP\nBatería: 5000 mAh\nSistema operativo: Android 13"));

        productos.add(new Producto("Huawei Mate 50 128GB", 7499, "https://i.pinimg.com/736x/3f/d6/2c/3fd62cdd57b66337e2d71645ab9014bd.jpg",
            "Pantalla: 6.7\" OLED\nProcesador: Snapdragon 8+ Gen 1\nRAM: 8 GB\nAlmacenamiento: 128/256 GB\nCámara trasera: Triple (50 MP + 13 MP + 12 MP)\nCámara frontal: 13 MP\nBatería: 4360 mAh\nSistema operativo: HarmonyOS 3.0"));

        productos.add(new Producto("Xiaomi 13 Ultra", 10999, "https://i.pinimg.com/736x/52/38/2b/52382b2db37bac39e3d11bb194542721.jpg",
            "Pantalla: 6.73\" AMOLED\nProcesador: Snapdragon 8 Gen 2\nRAM: 12/16 GB\nAlmacenamiento: 256/512 GB\nCámara trasera: Cuádruple (50 MP + 50 MP + 50 MP + 50 MP)\nCámara frontal: 32 MP\nBatería: 5000 mAh\nSistema operativo: Android 13"));
    }

    @SuppressWarnings("unused")
    private void initUI() {
        setTitle("Tienda de Celulares");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    
        panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        panel.setBackground(new Color(173, 216, 230));
    
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout(FlowLayout.CENTER));
    
        // ComboBox para filtrar productos por precio
        String[] opcionesFiltro = {"Todos", "Menos de $300", "Entre $300 y $600", "Entre $600 y $1000", "Más de $1000"};
        comboFiltroPrecio = new JComboBox<>(opcionesFiltro);
        comboFiltroPrecio.addActionListener(e -> filtrarProductos());
        panelBotones.add(comboFiltroPrecio);
    
        // botón para mostrar todos los productos
        JButton btnMostrarTodos = new JButton("Mostrar Todos los Productos");
        btnMostrarTodos.setBackground(Color.CYAN);
        btnMostrarTodos.setForeground(Color.BLACK);
        btnMostrarTodos.addActionListener(e -> mostrarProductos());
    
        JButton btnDetalles = new JButton("Ver Detalles");
        btnDetalles.setBackground(Color.ORANGE);
        btnDetalles.setForeground(Color.WHITE);
        btnDetalles.addActionListener(e -> verDetalles());
    
        // Crear un botón para retroceder
        JButton btnRetroceder = new JButton("Retroceder");
        btnRetroceder.setBackground(Color.RED);
        btnRetroceder.setForeground(Color.WHITE);
        btnRetroceder.setIcon(UIManager.getIcon("Button.back")); // Usa un ícono prediseñado
        btnRetroceder.addActionListener(e -> retroceder());

        // Botón para ver el carrito
        JButton btnVerCarrito = new JButton("Ver Carrito");
        btnVerCarrito.setBackground(Color.GREEN);
        btnVerCarrito.setForeground(Color.BLACK);
        btnVerCarrito.addActionListener(e -> verCarrito());
        panelBotones.add(btnVerCarrito);
    
        JButton btnAgregarCarrito = new JButton("Agregar al Carrito");
btnAgregarCarrito.setBackground(Color.YELLOW);
btnAgregarCarrito.setForeground(Color.BLACK);
btnAgregarCarrito.addActionListener(e -> agregarAlCarrito());
panelBotones.add(btnAgregarCarrito); // Añadir el botón al panel de botones

        // Botón para aceptar la compra
    JButton btnAceptarCompra = new JButton("Aceptar Compra");
    btnAceptarCompra.setBackground(Color.MAGENTA);
    btnAceptarCompra.setForeground(Color.WHITE);
    btnAceptarCompra.addActionListener(e -> aceptarCompra());
    panelBotones.add(btnAceptarCompra); // Añadir el botón al panel de botones

    
        // Usar un ícono de flecha hacia atrás prediseñado
    
        btnRetroceder.addActionListener(e -> retroceder());
    
        // Añadir botones al panel de botones
        panelBotones.add(btnMostrarTodos);
        panelBotones.add(btnDetalles);
        panelBotones.add(btnRetroceder);
    
        panel.add(panelBotones, BorderLayout.NORTH);
        
        // Crear un panel para mostrar los productos en un GridLayout
        panelProductos = new JPanel();
        panelProductos.setLayout(new GridLayout(0, 3, 10, 10));
        panel.add(panelProductos, BorderLayout.CENTER);
    
        JScrollPane scrollPane = new JScrollPane(panel);
        add(scrollPane);
    
        mostrarMensajeBienvenida(); // Mostrar mensaje de bienvenida al iniciar
    }

    private void mostrarMensajeBienvenida() {
        JOptionPane.showMessageDialog(this, "Bienvenido a la Tienda de Celulares!", "Bienvenida", JOptionPane.INFORMATION_MESSAGE);
    }

    private void filtrarProductos() {
        String seleccion = (String) comboFiltroPrecio.getSelectedItem();
        panelProductos.removeAll(); // Limpiar el panel antes de mostrar productos filtrados
        
        for (Producto producto : productos) {
            boolean agregar = false;
            switch (seleccion) {
                case "Todos" -> agregar = true;
                case "Menos de $300" -> {
                    if (producto.getPrecio() < 300) agregar = true;
                }
                case "Entre $300 y $600" -> {
                    if (producto.getPrecio() >= 300 && producto.getPrecio() <= 600) agregar = true;
                }
                case "Entre $600 y $1000" -> {
                    if (producto.getPrecio() > 600 && producto.getPrecio() <= 1000) agregar = true;
                }
                case "Más de $1000" -> {
                    if (producto.getPrecio() > 1000) agregar = true;
                }
            }
            if (agregar) {
                JPanel productoPanel = new JPanel();
                productoPanel.setLayout(new BorderLayout());
                
                JLabel imagenLabel = new JLabel(producto.getImagen());
                JLabel nombreLabel = new JLabel("<html><b>" + producto.getNombre() + "</b><br/>$" + producto.getPrecio() + "</html>", SwingConstants.CENTER);
                
                productoPanel.add(imagenLabel, BorderLayout.CENTER);
                productoPanel.add(nombreLabel, BorderLayout.NORTH); // Cambiar para que el nombre esté en la parte superior
                
                // Crear un botón para ver detalles del producto
                JButton btnDetalles = new JButton("Ver Detalles");
                btnDetalles.addActionListener(e -> {
                    productoSeleccionado = producto; // Guardar el producto seleccionado
                    verDetalles(); // Llamar al método para mostrar los detalles
                });
                
                productoPanel.add(btnDetalles, BorderLayout.SOUTH); // Añadir el botón en la parte inferior
                
                // Agregar un MouseListener para seleccionar el producto al hacer clic
                productoPanel.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        productoSeleccionado = producto; // Guardar el producto seleccionado
                        productoPanel.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2)); // Cambiar el borde para indicar selección
                        // Limpiar la selección de otros productos
                        for (Component comp : panelProductos.getComponents()) {
                            if (comp != productoPanel) {
                                ((JComponent) comp).setBorder(null); // Quitar el borde de otros productos
                            }
                        }
                    }
                });
                
                panelProductos.add(productoPanel);
            }
        }
        panelProductos.revalidate(); // Revalidar el panel para que se actualice la visualización
        panelProductos.repaint(); // Repintar el panel
    }

    private void mostrarProductos() {
        panelProductos.removeAll(); // Limpiar el panel antes de mostrar productos
        for (Producto producto : productos) {
            JPanel productoPanel = new JPanel();
            productoPanel.setLayout(new BorderLayout());
            
            JLabel imagenLabel = new JLabel(producto.getImagen());
            JLabel nombreLabel = new JLabel("<html><b>" + producto.getNombre() + "</b><br/>$" + producto.getPrecio() + "</html>", SwingConstants.CENTER);
            
            productoPanel.add(imagenLabel, BorderLayout.CENTER);
            productoPanel.add(nombreLabel, BorderLayout.NORTH); // Cambiar para que el nombre esté en la parte superior
            
            // Crear un botón para ver detalles del producto
            JButton btnDetalles = new JButton("Ver Detalles");
            btnDetalles.addActionListener(e -> {
                productoSeleccionado = producto; // Guardar el producto seleccionado
                verDetalles(); // Llamar al método para mostrar los detalles
            });
            
            productoPanel.add(btnDetalles, BorderLayout.SOUTH); // Añadir el botón en la parte inferior
            
            // Agregar un MouseListener para seleccionar el producto al hacer clic
            productoPanel.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    productoSeleccionado = producto; // Guardar el producto seleccionado
                    productoPanel.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2)); // Cambiar el borde para indicar selección
                    // Limpiar la selección de otros productos
                    for (Component comp : panelProductos.getComponents()) {
                        if (comp != productoPanel) {
                            ((JComponent) comp).setBorder(null); // Quitar el borde de otros productos
                        }
                    }
                }
            });
            
            panelProductos.add(productoPanel);
        }
        panelProductos.revalidate(); // Revalidar el panel para que se actualice la visualización
        panelProductos.repaint(); // Repintar el panel
    }

    private void verDetalles() {
        if (productoSeleccionado != null) {
            String detalles = "Nombre: " + productoSeleccionado.getNombre() + "\n" +
            "Precio: $" + productoSeleccionado.getPrecio() + " COP\n" + // Cambiar a COP
            "Especificaciones:\n" + productoSeleccionado.getEspecificaciones();
            JOptionPane.showMessageDialog(this, detalles, "Detalles del Producto", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un producto de la cuadrícula.");
        }
    }

    private void retroceder() {
        // Retroceder a la pantalla anterior o limpiar la vista actual
        panelProductos.removeAll(); // Limpiar el panel de productos
        panelProductos.revalidate(); // Revalidar el panel
        panelProductos.repaint(); // Repintar el panel
        JOptionPane.showMessageDialog(this, "Has retrocedido a la vista inicial.");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TiendaCelularesGUI tienda = new TiendaCelularesGUI();
            tienda.setVisible(true);
        });
    }
}